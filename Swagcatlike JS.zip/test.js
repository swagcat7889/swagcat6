const fetch = require('node-fetch');
let asdf
asdf = 0
const syncWait = (ms) => {
    const end = Date.now() + ms;
    while (Date.now() < end) continue;
  };
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  process.on('unhandledRejection', (error) => { // unhandled promise rejection
    console.error('Unhandled promise rejection:', error);
    asdf++
    syncWait(500);
  });
async function test() {
  i = 0
  while (true) {
      fetch(`http://earthshaker.nuio00.tk/`);
      i++
      console.log(i);
  }
}
test();