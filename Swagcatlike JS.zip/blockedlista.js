const blockedUsers = [`undefined`, `undefined`];
if (blockedUsers.Users.includes(interaction.user.id)) return;
