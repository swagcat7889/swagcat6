const fs = require('fs');
const {Client, Collection, Intents} = require('discord.js');
const {token} = require('./config.json');
const wait = require('util').promisify(setTimeout);
const client = new Client({intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.GUILD_MEMBERS]});
client.on('guildMemberAdd', (member) => {
  console.log(`New User "${member.user.username}" has joined "${member.guild.name}"` );
});
client.commands = new Collection();
const commandFiles = fs.readdirSync('./komendy').filter((file) => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(`./komendy/${file}`);
  console.log(`ok: ${file}`);
  client.commands.set(command.data.name, command);
}

client.once('ready', async (client) => {
  console.log('Gotowe!');
  wait(250);
  const { version } = require(`./package.json`);
  client.user.setActivity(`SwagCat ${version}`, {type: `PLAYING`});
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isCommand()) return;

  if (interaction.user.id == 646526456561795113) return;

  const command = client.commands.get(interaction.commandName);

  //	if (!command) return;

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(error);
    try {
		  return interaction.reply({content: 'There was an error while executing this command!', ephemeral: true});
    } catch (err) {
      return interaction.editReply(`There was an error while executing this command!`);
    }
  }
});

client.login(token);
client.on('shardError', (error) => { // ws error
  console.error('A websocket connection encountered an error:', error);
});
process.on('unhandledRejection', (error) => { // unhandled promise rejection
  console.error('Unhandled promise rejection:', error);
});
client.on('error', (error) => { // just error
  console.error('An error occurred: ', error);
});
client.on('interactionCreate', (interaction) => {
  if (!interaction.isButton()) return;
  if (interaction.customId == `help`) return;
  console.log(interaction);
  interaction.reply({content: `Swagcatlike\n/kupon - Kupon na swagcata!\n/rickroll - Never gonna give you up~\n/eval <kod> - uruchom kod! (tylko dla developerów bota)\n/help - Try it and see™️\n/ping - ${interaction.client.ws.ping}ms pingu!\n/kot - kiteł :)`, ephemeral: true});
  const logi = client.channels.cache.get(`894956743799484427`);
  logi.send(`${interaction.user.tag}`);
});
client.on('messageCreate', async (message) => {
  inc = message.content.includes(client.token);
  if (inc) {
    message.delete();
  }
	   });
